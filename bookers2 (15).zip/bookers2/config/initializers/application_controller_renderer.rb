# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'cef41164fb02ad47106fa58140de531f2e833d1bcdd80d4dc17996b4ecba01835d90e214e99882de61d53269ed815b081d67bd47e38622176270817748ab036c'

